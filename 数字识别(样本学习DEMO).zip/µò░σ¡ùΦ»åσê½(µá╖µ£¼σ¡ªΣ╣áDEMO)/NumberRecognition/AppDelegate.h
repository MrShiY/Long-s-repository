//
//  AppDelegate.h
//  NumberRecognition
//
//  Created by shiyonglong on 11/07/2017.
//  Copyright © 2017 startiasoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

